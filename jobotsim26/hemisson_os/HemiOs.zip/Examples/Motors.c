#include <hemisson.h>

// Add your variables here
// ...

void main()
{
	hemisson_init();				// Start Hemisson Initialisation
	while(1)
	{
		// Add your Code here
		// ...
		hemisson_set_speed(5,5);		// Go straight
		hemisson_delay_s(2);			// Wait 2s
		hemisson_set_speed(5,-5);		// Turn right
		hemisson_delay_s(2);			// Wait 2s
		hemisson_set_speed(0,0);		// Stop
		hemisson_delay_s(2);			// Wait 2s
		hemisson_set_speed(-5,-5);		// Rear
		hemisson_delay_s(2);			// Wait 2s
		hemisson_set_speed(-5,5);		// Turn Left
		hemisson_delay_s(2);             	// Wait 2s
		hemisson_set_speed(0,0);		// Turn Left
		hemisson_delay_s(2);             	// Wait 2s
    	}
}
