#define distance_sensor_enable(a,b)
#define distance_sensor_get_value(a) hemisson_get_proximity(a)
