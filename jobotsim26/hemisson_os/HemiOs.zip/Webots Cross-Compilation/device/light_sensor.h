#define light_sensor_enable(a,b)
#define light_sensor_get_value(a) hemisson_get_brightness(a)
