com.sunspotworld.demo.wot.visualization.pv.ledchart = {};

com.sunspotworld.demo.wot.visualization.pv.ledchart.ProtovisLedChart = function(container) {
  this.containerElement = container;
}

com.sunspotworld.demo.wot.visualization.pv.ledchart.ProtovisLedChart.prototype.getHeight = function() {
  return this.height;
}

com.sunspotworld.demo.wot.visualization.pv.ledchart.ProtovisLedChart.prototype.getWidth = function() {
  return this.width;
}

com.sunspotworld.demo.wot.visualization.pv.ledchart.ProtovisLedChart.prototype.setHeight = function(height) {
  this.height = height;
}

com.sunspotworld.demo.wot.visualization.pv.ledchart.ProtovisLedChart.prototype.setWidth = function(width) {
  this.width = width;
}

com.sunspotworld.demo.wot.visualization.pv.ledchart.ProtovisLedChart.prototype.setSize = function(width, height) {
  this.setWidth(width);
  this.setHeight(height);
}

com.sunspotworld.demo.wot.visualization.pv.ledchart.ProtovisLedChart.prototype.draw = function(dataTable, options) {
	
	var bottomMargin = 0,	//	30,
		leftMargin = 0,	//	30,
		rightMargin = 0,	//	30,
		topMargin = 0;	//	30,
	
	var w = options.width - leftMargin - rightMargin,
		h = options.height - topMargin - bottomMargin;
		
//	The root panel.
	var vis = new window.pv.Panel()
		.canvas(this.containerElement)
		.width(w)
		.height(h)
		.bottom(bottomMargin)
		.left(leftMargin)
		.right(rightMargin)
		.top(topMargin);
		
	var rowIndex = dataTable.getNumberOfRows() - 1;
		
	if (rowIndex >= 0) {
		
		var timestampColumnIndex = 0, redColumnIndex = 1, greenColumnIndex = 2, blueColumnIndex = 3;
		
		var data = new Array();
		
		var led = new Object();
		
		led.timestamp = new Object();
		
		led.timestamp.value = dataTable.getValue(rowIndex, timestampColumnIndex);
		led.timestamp.formatted = dataTable.getFormattedValue(rowIndex, timestampColumnIndex);
		led.red = dataTable.getValue(rowIndex, redColumnIndex);
		led.green = dataTable.getValue(rowIndex, greenColumnIndex);
		led.blue = dataTable.getValue(rowIndex, blueColumnIndex);
		
		data.push(led);
		
		//	The LED
		var leds = vis.add(window.pv.Bar)
			.data(data)
			.strokeStyle(function(d){
			return "black";
			}).fillStyle(function(d){
				return "rgb(" + d.red + ", " + d.green + ", " + d.blue + ")";
			})
		
		leds.anchor("bottom").add(window.pv.Label)
			.visible(false)
			.fillStyle(function(d){
				return "yellow";
			})
			.text(function(d){
				return "RGB(" + d.red + ", " + d.green + ", " + d.blue + ")";
			});
	}
		
	vis.render();
	
}
