com.sunspotworld.demo.wot.visualization.pv.linechart = {};

com.sunspotworld.demo.wot.visualization.pv.linechart.ProtovisLineChart = function(container) {
  this.containerElement = container;
}


com.sunspotworld.demo.wot.visualization.pv.linechart.ProtovisLineChart.prototype.draw = function(dataTable, options){

	var server_unreachable_error_code = 0,
		service_error_code = 1,
		service_success_code = 2;
		
	var status_colors = new Array();
		status_colors[server_unreachable_error_code] = "red";
		status_colors[service_error_code] = "yellow";
		status_colors[service_success_code] = "green";

//	Set the X axis and Y axis column indeces	
	var xAxisColumnIndex = 0,
		yAxisColumnIndex = 1,
		statusAxisColumnIndex = 2;

//	Set the border margins
	var bottomMargin = 5,
		leftMargin = 25,
		rightMargin = 5,
		topMargin = 10;

//	Compute the actual width and height, given the margins
	var w = options.width - leftMargin - rightMargin,
		h = options.height - topMargin - bottomMargin;

//	Define the root panel	
	var vis = new window.pv.Panel()
		.canvas(this.containerElement)
		.width(w)
		.height(h)
		.bottom(bottomMargin)
		.left(leftMargin)
		.right(rightMargin)
		.top(topMargin)
		.events("all")
		.event("mousemove", window.pv.Behavior.point());

//	Define the X axis length and the Y axis minimum and maximum values, as well as the Y axis buffer	
	var ymin,
		ymax,
		yAxisLength,
		yAxisBuffer;
	
	var xValues = new Array();
	
	var data = new Array();
	
	if (dataTable.getNumberOfRows() > 0) {
		
		var j = 0, k = 0;
		
		data = new Array();
		
		for (var i = 0; i < dataTable.getNumberOfRows(); i++) {
			var datum = new Object();
			datum.id = i
			datum.x = new Object();
			datum.x.value = dataTable.getValue(i, xAxisColumnIndex);
			datum.x.formatted = dataTable.getFormattedValue(i, xAxisColumnIndex);
			datum.y = new Object();
			datum.y.value = dataTable.getValue(i, yAxisColumnIndex);
			datum.y.formatted = dataTable.getFormattedValue(i, yAxisColumnIndex);
			datum.row = i;
			datum.column = yAxisColumnIndex;
			datum.status = dataTable.getValue(i, statusAxisColumnIndex);;
			data[i] = datum;
			xValues[i] = i;
		};
		
//		xValues[dataTable.getNumberOfRows()] = dataTable.getNumberOfRows();
		
		var bufferRatio = 0.05;

		var xAxisBuffer = 5;
			
	} else {
//		Otherwise, use default values for X axis length and Y axis
		xValues[0] = 0;
		xValues[1] = 1;
		
	}
	
	ymin = options.yAxisMin;
	ymax = options.yAxisMax;
	yAxisLength = ymax - ymin;
	yAxisBuffer = yAxisLength * bufferRatio;
	
	var x = window.pv.Scale.ordinal(xValues).split(xAxisBuffer, w), 
		y = window.pv.Scale.linear(ymin - yAxisBuffer, ymax + yAxisBuffer).range(0, h);
		
//	Draw axes

	var factor = Math.ceil((y.ticks().length)/4);	
	
//	Y-axis and ticks.
	var yAxis = vis.add(window.pv.Rule)
		.data(y.ticks())
		.visible(function(d) {return this.index%factor == 0;})
		.bottom(y)
		.strokeStyle(function(d) {return d ? "#eee" : "#000";});
		
	yAxis.anchor("left").add(window.pv.Label)
//		.visible(function(d) {return d > ymin - yAxisBuffer && d < ymax + yAxisBuffer;})
		.text(y.tickFormat);
		
	yAxis.anchor("right").add(window.pv.Dot)
		.shape("triangle")
		.strokeStyle(function(d) {return d ? "#eee" : "#000";})
		.fillStyle(function(d) {return d ? "#eee" : "#000";})
		.angle(function(){
			return Math.PI * 3 / 2;
		})
		.visible(function(d) {return !d;});
		

//	X-axis and ticks.
	var xAxis = vis.add(window.pv.Rule)
	    .data(xValues)
//	    .visible(function(d) {return this.index%factor == 0;})
	    .left(x)
	    .strokeStyle(function(d) {return d ? "#eee" : "#000";});
		
	xAxis.anchor("top").add(window.pv.Dot)
		.shape("triangle")
		.strokeStyle(function(d) {return d ? "#eee" : "#000";})
		.fillStyle(function(d) {return d ? "#eee" : "#000";})
		.angle(function(){
			return -Math.PI;
		})
		.visible(function(d) {return !d;});
	
//	Draw axis labels

	var yLabel = options.yLabel,
		xLabel = options.xLabel;

	vis.add(window.pv.Label)
		.bottom(function() {return 0;})
		.left(function() {return vis.width()/2;})
		.textAlign("center")
		.text(xLabel);
		
	vis.add(window.pv.Label)
		.bottom(function(){ return vis.height() / 2; })
		.left(function() {return xAxisBuffer;})
		.textAlign("center")
		.textAngle(function(){
			return -Math.PI / 2;
		})
		.text(yLabel);

//	Draw legend
//	Plot data
						
//	The dot plot!

	if (dataTable.getNumberOfRows() > 1) {
		
		var lines = vis.add(window.pv.Line)
		    .def("active", -1)
		    .data(data)
		    .left(function(d) {return x(d.id);})
		    .bottom(function(d) {return y(d.y.value);})
			.strokeStyle(function(d){
				return "black";
			})
		    .event("point", function() {
				return this.active(this.index).parent;
			})
		    .event("unpoint", function() {
				return this.active(-1).parent;
			});
			
//		lines.anchor("top").add(window.pv.Label)
//		    .visible(function() {return this.anchorTarget().active() == this.index;})
//		    .text(function(d) {return "(" + d.x.formatted + ", " + d.y.formatted + ")";});
	
		lines.add(window.pv.Dot)
			.strokeStyle(function(d){
				return status_colors[d.status];
			})
			.fillStyle(function(d){
				return status_colors[d.status];
			})
	}
		
	vis.render();
}
