// Declare a unique namespace.
var com = {};
com.sunspotworld = {};
com.sunspotworld.demo = {};
com.sunspotworld.demo.wot = {};
com.sunspotworld.demo.wot.visualization = {};
com.sunspotworld.demo.wot.visualization.pv = {};